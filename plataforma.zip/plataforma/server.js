const express = require('express');
const mysql = require('mysql2');
const path = require('path');

const app = express();
app.use(express.urlencoded({
    extended: true
}));

const session = require('express-session');

app.use(session({
    secret: 'mi-secreto',
    resave: false,
    saveUninitialized: true
}));



// Configuración de la conexión a la base de datos
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'learning',
});

// Ruta para manejar el registro de usuarios
app.post('/registrar', (req, res) => {
    const {
        nombre,
        email,
        password
    } = req.body;

    const query = 'INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)';
    const values = [nombre, email, password];

    connection.query(query, values, (error, results) => {
        if (error) {
            console.error('Error al guardar el usuario:', error);
            res.send('Error al registrar el usuario.');
        } else {
            console.log('Usuario registrado exitosamente.');
            res.send('Usuario registrado exitosamente.');
        }
    });
});

// Ruta para el inicio de sesión
app.get('/sesion.html', (req, res) => {
    res.render('sesion', {
        mensajeError: null
    });
});

// Ruta para el inicio de sesión
app.post('/iniciar-sesion', (req, res) => {
    const {
        email,
        password
    } = req.body;

    const query = 'SELECT * FROM usuarios WHERE email = ? AND password = ?';
    const values = [email, password];

    connection.query(query, values, (error, results) => {
        if (error) {
            console.error('Error al realizar la consulta:', error);
            res.render('sesion', {
                mensajeError: 'Error al iniciar sesión.'
            });
        } else {
            if (results.length > 0) {
                // El usuario ha iniciado sesión correctamente
                const nombreUsuario = results[0].nombre;
                res.render('bienvenido', {
                    nombreUsuario
                }); // Renderiza la página de bienvenida con el nombre del usuario
            } else {
                // Las credenciales son incorrectas
                res.render('sesion', {
                    mensajeError: 'Credenciales incorrectas.'
                });
            }
        }
    });
});

app.get('/cursos', (req, res) => {
    const query = 'SELECT * FROM cursos';
    connection.query(query, (error, results) => {
        if (error) {
            console.log(error);
            res.status(500).send('Error al obtener los cursos');
        } else {
            res.render('cursos', {
                nombreUsuario: req.session.nombreUsuario,
                cursos: results
            });
        }
    });
});

app.get('/perfil', (req, res) => {
    // Verificar si el usuario está autenticado
    if (req.session.nombreUsuario) {
        // Obtener el correo del usuario de la sesión
        const correoUsuario = req.session.correoUsuario;
        // Realizar una consulta a la base de datos para obtener la información del usuario
        const query = 'SELECT * FROM usuarios WHERE correo = ?';
        connection.query(query, [correoUsuario], (error, results) => {
            if (error) {
                throw error;
            }
            // Renderizar la página de perfil y pasar los datos del usuario como variables
            res.render('perfil', {
                usuario: results[0]
            });
        });
    } else {
        // Si el usuario no está autenticado, redireccionar al inicio de sesión
        res.redirect('/');
    }
});


// Configuración de la carpeta de archivos estáticos
app.use(express.static(path.join(__dirname, 'assets')));

// Configuración del motor de plantillas EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Ruta para la página principal
app.get('/', (req, res) => {
    res.render('index');
});

// Ruta para mostrar la página de registro
app.get('/registrarse.html', (req, res) => {
    res.render('registrarse'); // Renderiza el archivo "registrarse.ejs"
});
app.get('/courses.html', (req, res) => {
    res.render('courses');
});
app.get('/about.html', (req, res) => {
    res.render('about');
});


app.get('/bienvenido', (req, res) => {
    res.render('bienvenido', {
        nombreUsuario: 'John Doe'
    }); // Reemplaza 'John Doe' con el nombre de usuario real
});

app.get('/course-details.html', (req, res) => {
    res.render('course-details');
});

app.get('/usuarios.html', (req, res) => {
    res.render('usuarios');
});

app.get('/cerrar-sesion', (req, res) => {
    // Eliminar la sesión
    req.session.destroy();
    // Redireccionar al inicio
    res.redirect('/');
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('Servidor iniciado en http://localhost:3000');
});


// Cerrar la conexión al final del archivo
process.on('SIGINT', () => {
    connection.end();
    process.exit();
});